import os
from flask import Flask


def create_app():
    app = Flask(__name__, template_folder="templates", static_folder="static")
    app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "dev-secret-change-me-in-production")
    app.config["SESSION_COOKIE_HTTPONLY"] = True
    app.config["SESSION_COOKIE_SAMESITE"] = "Lax"

    from app.auth import auth_bp
    from app.dashboard import dashboard_bp
    from app.crud import crud_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(dashboard_bp)
    app.register_blueprint(crud_bp)

    @app.template_filter("fmtval")
    def fmtval(v):
        if isinstance(v, float):
            if v == int(v):
                return str(int(v))
            return f"{v:g}"
        return v

    from app.permissions import ROLE_LABELS, can_view
    from app.db.build_registry import REGISTRY
    from app.module_colors import MODULE_COLORS, MODULE_BG

    @app.context_processor
    def inject_globals():
        from app.auth import current_user
        user = current_user()
        visible_modules = []
        if user:
            for m in REGISTRY["modules"]:
                if can_view(user["role"], m["name"]):
                    visible_modules.append(m)
        return dict(
            nav_modules=visible_modules,
            role_labels=ROLE_LABELS,
            cur_user=user,
            module_colors=MODULE_COLORS,
            module_bg=MODULE_BG,
        )

    return app
