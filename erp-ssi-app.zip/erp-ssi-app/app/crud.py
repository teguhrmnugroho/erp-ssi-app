import math
from flask import Blueprint, render_template, request, redirect, url_for, flash, abort

from app.db.conn import get_connection, fetch_all, fetch_one, insert_and_get_id, update_row, delete_row
from app.db.build_registry import REGISTRY
from app.auth import login_required, current_user
from app.permissions import can_view, can_edit

crud_bp = Blueprint("crud", __name__, url_prefix="/data")

PAGE_SIZE = 20


def get_table(slug):
    t = REGISTRY["tables_by_slug"].get(slug)
    if not t:
        abort(404)
    return t


def _check_view(table):
    user = current_user()
    if not can_view(user["role"], table["modul"]):
        flash(f"Kamu tidak punya akses lihat modul '{table['modul']}'.", "error")
        return False
    return True


def _check_edit(table):
    user = current_user()
    if not can_edit(user["role"], table["modul"]):
        flash(f"Role kamu ({user['role']}) tidak punya akses ubah data di modul '{table['modul']}'.", "error")
        return False
    return True


def get_select_options(field):
    conn = get_connection()
    options = []
    if field["ref_kind"] == "ref_domain" and field["ref_domain"]:
        rows = fetch_all(conn, "SELECT label FROM reference_values WHERE domain = ? AND status_aktif = ? ORDER BY urutan",
                          [field["ref_domain"], 1])
        options = [(r["label"], r["label"]) for r in rows]
    elif field["ref_kind"] == "fk_table" and field["fk_target_slug"]:
        target = REGISTRY["tables_by_slug"].get(field["fk_target_slug"])
        if target:
            pk_col = target["pk_display_field"]
            name_col = target["display_field"]
            tname = f'tbl_{target["slug"]}'
            if pk_col and name_col and pk_col != name_col:
                rows = fetch_all(conn, f'SELECT "{pk_col}" as v, "{name_col}" as n FROM {tname} ORDER BY id DESC LIMIT 500')
                options = [(r["v"], f'{r["v"]} — {r["n"]}' if r["n"] else r["v"]) for r in rows if r["v"]]
            elif pk_col:
                rows = fetch_all(conn, f'SELECT "{pk_col}" as v FROM {tname} ORDER BY id DESC LIMIT 500')
                options = [(r["v"], r["v"]) for r in rows if r["v"]]
    conn.close()
    return options


def row_label(table, row):
    disp = table["display_field"]
    pk = table["pk_display_field"]
    parts = []
    if pk and row.get(pk):
        parts.append(str(row[pk]))
    if disp and disp != pk and row.get(disp):
        parts.append(str(row[disp]))
    return " — ".join(parts) if parts else f"#{row['id']}"


@crud_bp.route("/<slug>")
@login_required
def list_view(slug):
    table = get_table(slug)
    if not _check_view(table):
        return redirect(url_for("dashboard.home"))

    q = request.args.get("q", "").strip()
    page = max(1, int(request.args.get("page", 1) or 1))
    tname = f'tbl_{table["slug"]}'
    conn = get_connection()

    text_fields = [f["slug"] for f in table["fields"] if f["html_type"] in ("text", "textarea")][:6]
    where_sql = ""
    params = []
    if q and text_fields:
        conds = " OR ".join([f'"{f}" LIKE ?' for f in text_fields])
        where_sql = f"WHERE {conds}"
        params = [f"%{q}%"] * len(text_fields)

    total_row = fetch_one(conn, f"SELECT COUNT(*) as c FROM {tname} {where_sql}", params)
    total = total_row["c"] if total_row else 0
    total_pages = max(1, math.ceil(total / PAGE_SIZE))
    page = min(page, total_pages)
    offset = (page - 1) * PAGE_SIZE

    list_field_slugs = [f["slug"] for f in table["fields"]][:6]
    cols_sql = ", ".join([f'"{c}"' for c in ["id"] + list_field_slugs])
    rows = fetch_all(conn, f"SELECT {cols_sql} FROM {tname} {where_sql} ORDER BY id DESC LIMIT {PAGE_SIZE} OFFSET {offset}", params)
    conn.close()

    list_fields = [f for f in table["fields"] if f["slug"] in list_field_slugs]
    user = current_user()
    return render_template(
        "list.html", table=table, rows=rows, list_fields=list_fields,
        q=q, page=page, total_pages=total_pages, total=total,
        can_edit=can_edit(user["role"], table["modul"]),
    )


def _fields_for_form(table):
    return [f for f in table["fields"]]


def _parse_form_value(field, raw):
    if field["html_type"] == "checkbox":
        return 1 if raw else 0
    raw = (raw or "").strip()
    if raw == "":
        return None
    if field["html_type"] == "number":
        try:
            if field["step"] == "1":
                return int(float(raw))
            return float(raw)
        except ValueError:
            return None
    return raw


@crud_bp.route("/<slug>/new", methods=["GET", "POST"])
@login_required
def create_view(slug):
    table = get_table(slug)
    if not _check_view(table):
        return redirect(url_for("dashboard.home"))
    if not _check_edit(table):
        return redirect(url_for("crud.list_view", slug=slug))

    fields = _fields_for_form(table)
    options_cache = {f["slug"]: get_select_options(f) for f in fields if f["ref_kind"] in ("ref_domain", "fk_table")}

    if request.method == "POST":
        columns, values = [], []
        missing = []
        for f in fields:
            raw = request.form.get(f["slug"])
            val = _parse_form_value(f, raw)
            if f["required"] and (val is None or val == ""):
                missing.append(f["label"])
            columns.append(f["slug"])
            values.append(val)
        if missing:
            flash("Field wajib belum diisi: " + ", ".join(missing), "error")
        else:
            user = current_user()
            columns += ["created_by", "updated_by"]
            values += [user["username"], user["username"]]
            try:
                new_id = insert_and_get_id(get_connection(), f'tbl_{table["slug"]}', columns, values)
                flash(f'{table["kode"]} berhasil ditambahkan (#{new_id}).', "success")
                return redirect(url_for("crud.list_view", slug=slug))
            except Exception as e:
                flash(f"Gagal menyimpan: {e}", "error")

    return render_template("form.html", table=table, fields=fields, row=None, options_cache=options_cache, mode="create", can_edit=True)


@crud_bp.route("/<slug>/<int:row_id>/edit", methods=["GET", "POST"])
@login_required
def edit_view(slug, row_id):
    table = get_table(slug)
    if not _check_view(table):
        return redirect(url_for("dashboard.home"))

    tname = f'tbl_{table["slug"]}'
    conn = get_connection()
    row = fetch_one(conn, f"SELECT * FROM {tname} WHERE id = ?", [row_id])
    conn.close()
    if not row:
        abort(404)

    can_edit_this = can_edit(current_user()["role"], table["modul"])
    fields = _fields_for_form(table)
    options_cache = {f["slug"]: get_select_options(f) for f in fields if f["ref_kind"] in ("ref_domain", "fk_table")}

    if request.method == "POST":
        if not can_edit_this:
            flash("Role kamu tidak punya akses ubah data di modul ini.", "error")
            return redirect(url_for("crud.list_view", slug=slug))
        columns, values = [], []
        missing = []
        for f in fields:
            raw = request.form.get(f["slug"])
            val = _parse_form_value(f, raw)
            if f["required"] and (val is None or val == ""):
                missing.append(f["label"])
            columns.append(f["slug"])
            values.append(val)
        if missing:
            flash("Field wajib belum diisi: " + ", ".join(missing), "error")
        else:
            user = current_user()
            columns += ["updated_by"]
            values += [user["username"]]
            try:
                update_row(get_connection(), tname, columns, values, row_id)
                flash(f'{table["kode"]} #{row_id} berhasil diperbarui.', "success")
                return redirect(url_for("crud.list_view", slug=slug))
            except Exception as e:
                flash(f"Gagal menyimpan: {e}", "error")

    return render_template("form.html", table=table, fields=fields, row=row, options_cache=options_cache,
                            mode="edit", can_edit=can_edit_this)


@crud_bp.route("/<slug>/<int:row_id>/delete", methods=["POST"])
@login_required
def delete_view(slug, row_id):
    table = get_table(slug)
    if not _check_view(table) or not _check_edit(table):
        return redirect(url_for("dashboard.home"))
    try:
        delete_row(get_connection(), f'tbl_{table["slug"]}', row_id)
        flash(f'{table["kode"]} #{row_id} dihapus.', "success")
    except Exception as e:
        flash(f"Gagal menghapus: {e}", "error")
    return redirect(url_for("crud.list_view", slug=slug))
