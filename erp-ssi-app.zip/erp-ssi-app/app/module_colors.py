MODULE_COLORS = {
    "A. Master & Referensi": "#7C3AED",
    "B. Penjualan / PO": "#4F46E5",
    "C. Produksi": "#D97706",
    "D. Persediaan & Gudang (WMS)": "#059669",
    "E. Pembiayaan (Funding)": "#DC2626",
    "F. Keuangan Operasional": "#4B5563",
    "G. Administrasi & Legal": "#C2410C",
    "H. HR": "#DB2777",
}
MODULE_BG = {
    "A. Master & Referensi": "#EDE9FE",
    "B. Penjualan / PO": "#E0E7FF",
    "C. Produksi": "#FEF3C7",
    "D. Persediaan & Gudang (WMS)": "#D1FAE5",
    "E. Pembiayaan (Funding)": "#FEE2E2",
    "F. Keuangan Operasional": "#F3F4F6",
    "G. Administrasi & Legal": "#FFF1E6",
    "H. HR": "#FCE7F3",
}
