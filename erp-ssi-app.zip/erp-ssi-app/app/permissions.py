#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Role & matriks hak akses per modul. Role diselaraskan dgn domain 'Departemen'
di Master Data (Produksi, PPIC, QC, Gudang, Finance, Purchasing, Sales/Marketing,
Ekspor/Logistik, HR) + role ADMIN.

Kebijakan: ADMIN selalu full-access. Modul Pembiayaan (Funding) & Keuangan
Operasional dibatasi hanya utk ADMIN + FINANCE (data sensitif, sesuai catatan
di Data Dictionary Excel: 'Terapkan role-based access control utk data sensitif').
Modul lain: semua role yg login bisa melihat (view), tapi hanya role terkait yg
bisa tambah/ubah/hapus (edit).
"""

ROLES = [
    ("ADMIN", "Admin"),
    ("PRODUKSI", "Produksi"),
    ("PPIC", "PPIC"),
    ("QC", "QC"),
    ("GUDANG", "Gudang"),
    ("FINANCE", "Finance"),
    ("PURCHASING", "Purchasing"),
    ("SALES_MARKETING", "Sales/Marketing"),
    ("EKSPOR_LOGISTIK", "Ekspor/Logistik"),
    ("HR", "HR"),
]
ROLE_LABELS = dict(ROLES)

ALL_ROLES = [r[0] for r in ROLES]

PERMISSIONS = {
    "A. Master & Referensi": {"view": ALL_ROLES, "edit": ["ADMIN"]},
    "B. Penjualan / PO": {"view": ALL_ROLES, "edit": ["ADMIN", "PPIC", "SALES_MARKETING", "FINANCE"]},
    "C. Produksi": {"view": ALL_ROLES, "edit": ["ADMIN", "PRODUKSI", "PPIC", "QC"]},
    "D. Persediaan & Gudang (WMS)": {"view": ALL_ROLES, "edit": ["ADMIN", "GUDANG", "PRODUKSI", "PURCHASING"]},
    "E. Pembiayaan (Funding)": {"view": ["ADMIN", "FINANCE"], "edit": ["ADMIN", "FINANCE"]},
    "F. Keuangan Operasional": {"view": ["ADMIN", "FINANCE"], "edit": ["ADMIN", "FINANCE", "PURCHASING"]},
    "G. Administrasi & Legal": {"view": ALL_ROLES, "edit": ["ADMIN", "PPIC", "SALES_MARKETING", "EKSPOR_LOGISTIK"]},
    "H. HR": {"view": ["ADMIN", "HR"], "edit": ["ADMIN", "HR"]},
}


def can_view(role, modul):
    rule = PERMISSIONS.get(modul)
    if not rule:
        return False
    if role == "ADMIN":
        return True
    return rule["view"] == ALL_ROLES or role in rule["view"]


def can_edit(role, modul):
    rule = PERMISSIONS.get(modul)
    if not rule:
        return False
    return role == "ADMIN" or role in rule["edit"]


DEFAULT_USERS = [
    # username, full_name, role, password
    ("admin", "Administrator", "ADMIN", "Admin#SSI2026"),
    ("produksi", "User Produksi", "PRODUKSI", "Produksi#2026"),
    ("ppic", "User PPIC", "PPIC", "Ppic#2026"),
    ("qc", "User QC", "QC", "Qc#2026"),
    ("gudang", "User Gudang", "GUDANG", "Gudang#2026"),
    ("finance", "User Finance", "FINANCE", "Finance#2026"),
    ("purchasing", "User Purchasing", "PURCHASING", "Purchasing#2026"),
    ("sales", "User Sales/Marketing", "SALES_MARKETING", "Sales#2026"),
    ("logistik", "User Ekspor/Logistik", "EKSPOR_LOGISTIK", "Logistik#2026"),
    ("hr", "User HR", "HR", "Hr#2026"),
]
