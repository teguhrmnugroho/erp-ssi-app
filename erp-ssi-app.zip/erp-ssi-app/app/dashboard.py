from flask import Blueprint, render_template

from app.db.conn import get_connection, fetch_one
from app.db.build_registry import REGISTRY
from app.auth import login_required, current_user
from app.permissions import can_view

dashboard_bp = Blueprint("dashboard", __name__)


@dashboard_bp.route("/")
@login_required
def home():
    user = current_user()
    conn = get_connection()
    modules_data = []
    for m in REGISTRY["modules"]:
        if not can_view(user["role"], m["name"]):
            continue
        table_counts = []
        total = 0
        for t in m["tables"]:
            r = fetch_one(conn, f'SELECT COUNT(*) as c FROM tbl_{t["slug"]}')
            c = r["c"] if r else 0
            total += c
            table_counts.append((t, c))
        modules_data.append(dict(modul=m["name"], tables=table_counts, total=total))
    conn.close()
    return render_template("dashboard.html", modules_data=modules_data)
