import functools
from flask import Blueprint, render_template, request, redirect, url_for, session, flash, g

from app.db.conn import get_connection, fetch_one
from app.auth_utils import verify_password
from app.permissions import can_view

auth_bp = Blueprint("auth", __name__)


def current_user():
    if "user_id" not in session:
        return None
    if "_user_cache" in g:
        return g._user_cache
    conn = get_connection()
    user = fetch_one(conn, "SELECT id, username, full_name, role, active FROM users WHERE id = ?", [session["user_id"]])
    conn.close()
    g._user_cache = user
    return user


def login_required(view):
    @functools.wraps(view)
    def wrapped(*args, **kwargs):
        if current_user() is None:
            return redirect(url_for("auth.login", next=request.path))
        return view(*args, **kwargs)
    return wrapped


def module_access_required(modul_getter):
    """Decorator factory: modul_getter(kwargs) -> nama modul yg mau diakses."""
    def decorator(view):
        @functools.wraps(view)
        def wrapped(*args, **kwargs):
            user = current_user()
            if user is None:
                return redirect(url_for("auth.login", next=request.path))
            modul = modul_getter(kwargs)
            if not can_view(user["role"], modul):
                flash(f"Kamu tidak punya akses ke modul '{modul}'.", "error")
                return redirect(url_for("dashboard.home"))
            return view(*args, **kwargs)
        return wrapped
    return decorator


@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        conn = get_connection()
        user = fetch_one(conn, "SELECT * FROM users WHERE username = ?", [username])
        conn.close()
        if user and user.get("active") and verify_password(password, user["password_hash"]):
            session.clear()
            session["user_id"] = user["id"]
            session.permanent = True
            flash(f"Selamat datang, {user['full_name']}.", "success")
            next_url = request.args.get("next") or url_for("dashboard.home")
            return redirect(next_url)
        flash("Username atau password salah.", "error")
    return render_template("login.html")


@auth_bp.route("/logout")
def logout():
    session.clear()
    flash("Kamu sudah logout.", "success")
    return redirect(url_for("auth.login"))
