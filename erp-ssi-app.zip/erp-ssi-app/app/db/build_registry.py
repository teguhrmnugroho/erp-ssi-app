#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Membangun 'registry' skema aplikasi dari tables_data.json (sumber yang sama
dipakai untuk Data Dictionary Excel) + master_data_dropdowns.json.

Registry ini dipakai oleh Flask app untuk:
- generate DDL (SQLite utk dev lokal, PostgreSQL utk produksi/Neon)
- generate form CRUD generik (field, tipe input, dropdown FK/referensi)
- generate menu navigasi per modul

Menambahkan kolom teknis yang tidak ada di desain data dictionary asli:
- id INTEGER PK auto-increment di setiap tabel (supaya routing CRUD generik
  sederhana), field2 desain asli (mis. "No PO") tetap disimpan sbg kolom
  biasa + unique constraint gabungan menggantikan PK komposit aslinya.
"""
import json
import re
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

with open(os.path.join(BASE_DIR, "tables_data.json"), encoding="utf-8") as f:
    _raw = json.load(f)
TABLES_RAW = _raw["tables"]
VIEWS_RAW = _raw["views"]

with open(os.path.join(BASE_DIR, "master_data_dropdowns.json"), encoding="utf-8") as f:
    REFERENCE_DOMAINS = json.load(f)

RESERVED = {"select", "table", "order", "group", "user", "default", "check", "column", "primary", "references"}


def slugify(name):
    s = name.lower()
    s = s.replace("%", "persen").replace("&", "dan").replace("/", "_")
    s = re.sub(r"[().,'\-]", " ", s)
    s = re.sub(r"[^a-z0-9_ ]", " ", s)
    s = re.sub(r"\s+", "_", s.strip())
    s = re.sub(r"_+", "_", s).strip("_")
    if not s:
        s = "field"
    if s[0].isdigit():
        s = "f_" + s
    if s in RESERVED:
        s = s + "_val"
    return s


def table_slug(kode):
    # TBL_PO_MAKLON -> po_maklon
    s = kode.lower()
    if s.startswith("tbl_"):
        s = s[4:]
    return s


def parse_type(tipe_data):
    """Kembalikan (sqlite_type, postgres_type, html_input_type, step)"""
    t = tipe_data.upper()
    if t.startswith("VARCHAR") or t == "-":
        return "TEXT", "TEXT", "text", None
    if t.startswith("TEXT"):
        return "TEXT", "TEXT", "textarea", None
    if t.startswith("DECIMAL"):
        return "REAL", "NUMERIC(18,4)", "number", "any"
    if t.startswith("INT"):
        return "INTEGER", "INTEGER", "number", "1"
    if t == "DATE":
        return "TEXT", "DATE", "date", None
    if t == "DATETIME":
        return "TEXT", "TIMESTAMP", "datetime-local", None
    if t == "TIME":
        return "TEXT", "TIME", "time", None
    if t == "BOOLEAN":
        return "INTEGER", "BOOLEAN", "checkbox", None
    return "TEXT", "TEXT", "text", None


def parse_referensi(referensi):
    """Kembalikan dict: kind = 'ref_domain' | 'fk_table' | 'plain', domain=..., target_table=..."""
    if not referensi or referensi == "-":
        return {"kind": "plain"}
    m = re.search(r"TBL_REFERENSI\(([^)]+)\)", referensi)
    if m:
        return {"kind": "ref_domain", "domain": m.group(1).strip()}
    if "TBL_REFERENSI" in referensi:
        return {"kind": "plain"}
    m = re.search(r"(TBL_[A-Z_]+)", referensi)
    if m:
        target = m.group(1)
        # jangan link ke diri sendiri jadi fk kalau referensi cuma catatan
        return {"kind": "fk_table", "target_table": target}
    return {"kind": "plain"}


def build_registry():
    tables = []
    used_slugs = set()
    for t in TABLES_RAW:
        tslug = table_slug(t["kode"])
        if tslug in used_slugs:
            tslug += "_t"
        used_slugs.add(tslug)

        fields = []
        used_field_slugs = {"id"}
        business_pk_fields = []
        name_field_slug = None

        for (nama_field, tipe, key, referensi, wajib, ket) in t["fields"]:
            fslug = slugify(nama_field)
            base = fslug
            i = 2
            while fslug in used_field_slugs:
                fslug = f"{base}_{i}"
                i += 1
            used_field_slugs.add(fslug)

            sqlite_t, pg_t, html_t, step = parse_type(tipe)
            ref = parse_referensi(referensi)
            is_business_pk = key in ("PK", "PK, FK")
            required = wajib.strip().lower().startswith("ya") and wajib.strip() != "Ya (computed)"
            computed = "computed" in wajib.lower()

            field = dict(
                slug=fslug, label=nama_field, tipe_data=tipe, sqlite_type=sqlite_t,
                pg_type=pg_t, html_type=html_t, step=step, key=key,
                is_business_pk=is_business_pk, required=required and not computed,
                computed=computed, ref_kind=ref["kind"],
                ref_domain=ref.get("domain"), fk_target_table=ref.get("target_table"),
                keterangan=ket,
            )
            fields.append(field)
            if is_business_pk:
                business_pk_fields.append(fslug)
            if name_field_slug is None and ("nama" in fslug or "deskripsi" in fslug) and not is_business_pk:
                name_field_slug = fslug

        display_field = name_field_slug or (business_pk_fields[0] if business_pk_fields else (fields[0]["slug"] if fields else None))
        pk_display = business_pk_fields[0] if business_pk_fields else None

        tables.append(dict(
            kode=t["kode"], slug=tslug, modul=t["modul"], jenis=t["jenis"],
            sumber=t["sumber"], deskripsi=t["deskripsi"], fields=fields,
            business_pk_fields=business_pk_fields,
            pk_display_field=pk_display,
            display_field=display_field,
        ))

    # resolve fk_target_table (TBL code) -> slug, drop link if target not a real managed table
    slug_by_kode = {t["kode"]: t["slug"] for t in tables}
    for t in tables:
        for f in t["fields"]:
            if f["ref_kind"] == "fk_table":
                target_slug = slug_by_kode.get(f["fk_target_table"])
                if target_slug:
                    f["fk_target_slug"] = target_slug
                else:
                    f["ref_kind"] = "plain"
                    f["fk_target_slug"] = None
            else:
                f["fk_target_slug"] = None

    modules = []
    seen_mod = []
    for t in tables:
        if t["modul"] not in seen_mod:
            seen_mod.append(t["modul"])
    for m in seen_mod:
        modules.append(dict(name=m, tables=[t for t in tables if t["modul"] == m]))

    return dict(tables=tables, modules=modules, tables_by_slug={t["slug"]: t for t in tables})


REGISTRY = build_registry()

if __name__ == "__main__":
    print(f"{len(REGISTRY['tables'])} tabel dibangun ke registry.")
    for t in REGISTRY["tables"][:3]:
        print("-", t["kode"], "->", t["slug"], "| fields:", len(t["fields"]), "| display:", t["display_field"])
