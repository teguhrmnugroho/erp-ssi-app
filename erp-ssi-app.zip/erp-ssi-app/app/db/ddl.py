#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Generate DDL (CREATE TABLE) untuk dialek SQLite (dev lokal) dan PostgreSQL (produksi/Neon)
dari registry (build_registry.REGISTRY).

Catatan desain (lihat juga sheet 'Rekomendasi Penyesuaian' di Data Dictionary Excel):
- Setiap tabel bisnis dapat kolom teknis `id` (PK auto-increment) supaya routing CRUD
  generik sederhana. Business key asli (mis. "No PO") tetap kolom biasa + UNIQUE.
- Relasi antar tabel bisnis (FK) di versi MVP ini bersifat "soft link" (disimpan sbg
  teks kode, divalidasi via dropdown di form), BUKAN foreign key constraint keras di
  database -- supaya urutan input data lebih fleksibel selama masa percobaan.
  Rekomendasi jangka panjang (constraint keras + kode bukan nama) ada di dokumen
  Data Dictionary Excel, sheet 'Rekomendasi Penyesuaian'.
"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from build_registry import REGISTRY, REFERENCE_DOMAINS  # noqa

AUDIT_COLS_SQLITE = [
    ("created_at", "TEXT DEFAULT (datetime('now'))"),
    ("updated_at", "TEXT DEFAULT (datetime('now'))"),
    ("created_by", "TEXT"),
    ("updated_by", "TEXT"),
]
AUDIT_COLS_PG = [
    ("created_at", "TIMESTAMP DEFAULT NOW()"),
    ("updated_at", "TIMESTAMP DEFAULT NOW()"),
    ("created_by", "TEXT"),
    ("updated_by", "TEXT"),
]


def business_table_ddl(table, dialect):
    cols = []
    if dialect == "sqlite":
        cols.append("id INTEGER PRIMARY KEY AUTOINCREMENT")
    else:
        cols.append("id SERIAL PRIMARY KEY")

    for f in table["fields"]:
        t = f["sqlite_type"] if dialect == "sqlite" else f["pg_type"]
        cols.append(f'"{f["slug"]}" {t}')

    audit = AUDIT_COLS_SQLITE if dialect == "sqlite" else AUDIT_COLS_PG
    for name, spec in audit:
        cols.append(f'"{name}" {spec}')

    tname = f'tbl_{table["slug"]}'
    ddl = f'CREATE TABLE IF NOT EXISTS {tname} (\n  ' + ",\n  ".join(cols) + "\n);"

    extra = []
    if table["business_pk_fields"]:
        pk_col = table["business_pk_fields"][0]
        idx_name = f'ux_{table["slug"]}_{pk_col}'
        extra.append(f'CREATE UNIQUE INDEX IF NOT EXISTS {idx_name} ON {tname} ("{pk_col}");')
    return ddl, extra


def reference_values_ddl(dialect):
    if dialect == "sqlite":
        return (
            "CREATE TABLE IF NOT EXISTS reference_values (\n"
            "  id INTEGER PRIMARY KEY AUTOINCREMENT,\n"
            "  domain TEXT NOT NULL,\n"
            "  label TEXT NOT NULL,\n"
            "  urutan INTEGER DEFAULT 0,\n"
            "  status_aktif INTEGER DEFAULT 1\n"
            ");"
        )
    return (
        "CREATE TABLE IF NOT EXISTS reference_values (\n"
        "  id SERIAL PRIMARY KEY,\n"
        "  domain TEXT NOT NULL,\n"
        "  label TEXT NOT NULL,\n"
        "  urutan INTEGER DEFAULT 0,\n"
        "  status_aktif BOOLEAN DEFAULT TRUE\n"
        ");"
    )


def users_ddl(dialect):
    if dialect == "sqlite":
        return (
            "CREATE TABLE IF NOT EXISTS users (\n"
            "  id INTEGER PRIMARY KEY AUTOINCREMENT,\n"
            "  username TEXT NOT NULL UNIQUE,\n"
            "  password_hash TEXT NOT NULL,\n"
            "  full_name TEXT NOT NULL,\n"
            "  role TEXT NOT NULL,\n"
            "  active INTEGER DEFAULT 1,\n"
            "  created_at TEXT DEFAULT (datetime('now'))\n"
            ");"
        )
    return (
        "CREATE TABLE IF NOT EXISTS users (\n"
        "  id SERIAL PRIMARY KEY,\n"
        "  username TEXT NOT NULL UNIQUE,\n"
        "  password_hash TEXT NOT NULL,\n"
        "  full_name TEXT NOT NULL,\n"
        "  role TEXT NOT NULL,\n"
        "  active BOOLEAN DEFAULT TRUE,\n"
        "  created_at TIMESTAMP DEFAULT NOW()\n"
        ");"
    )


def generate_all_ddl(dialect):
    assert dialect in ("sqlite", "postgres")
    statements = [users_ddl(dialect), reference_values_ddl(dialect)]
    for t in REGISTRY["tables"]:
        main, extra = business_table_ddl(t, dialect)
        statements.append(main)
        statements.extend(extra)
    return statements


if __name__ == "__main__":
    import argparse
    p = argparse.ArgumentParser()
    p.add_argument("--dialect", choices=["sqlite", "postgres"], default="sqlite")
    p.add_argument("--out", default=None)
    args = p.parse_args()
    stmts = generate_all_ddl(args.dialect)
    out = "\n\n".join(stmts) + "\n"
    if args.out:
        with open(args.out, "w", encoding="utf-8") as f:
            f.write(out)
        print(f"Wrote {len(stmts)} statements to {args.out}")
    else:
        print(out)
