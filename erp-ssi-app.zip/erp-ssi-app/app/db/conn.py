#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Lapisan akses database generik yang mendukung dua dialek:
- SQLite (dev lokal, default, tanpa perlu setup apa pun)
- PostgreSQL (produksi, mis. Neon) -- aktif otomatis kalau env DATABASE_URL diisi
  dgn connection string postgres://... atau postgresql://...

Semua kode aplikasi menulis SQL dengan placeholder '?' gaya SQLite; helper di
sini yang menerjemahkan ke '%s' kalau target-nya PostgreSQL, supaya satu basis
kode bisa jalan di kedua dialek tanpa duplikasi query.
"""
import os
import sqlite3

DATABASE_URL = os.environ.get("DATABASE_URL", "").strip()
IS_POSTGRES = DATABASE_URL.startswith("postgres://") or DATABASE_URL.startswith("postgresql://")

if IS_POSTGRES:
    import psycopg2
    import psycopg2.extras

APP_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SQLITE_PATH = os.environ.get("SQLITE_PATH", os.path.join(APP_DIR, "..", "erp_dev.db"))


def get_connection():
    if IS_POSTGRES:
        # Neon & sejenisnya umumnya mewajibkan SSL
        dsn = DATABASE_URL
        if "sslmode" not in dsn:
            sep = "&" if "?" in dsn else "?"
            dsn = f"{dsn}{sep}sslmode=require"
        conn = psycopg2.connect(dsn, cursor_factory=psycopg2.extras.RealDictCursor)
        return conn
    else:
        conn = sqlite3.connect(SQLITE_PATH)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON")
        return conn


def _translate(sql):
    return sql.replace("?", "%s") if IS_POSTGRES else sql


def execute(conn, sql, params=None):
    cur = conn.cursor()
    cur.execute(_translate(sql), params or [])
    return cur


def executescript(conn, sql_statements):
    cur = conn.cursor()
    for stmt in sql_statements:
        if stmt.strip():
            cur.execute(stmt)
    conn.commit()


def fetch_all(conn, sql, params=None):
    cur = execute(conn, sql, params)
    rows = cur.fetchall()
    return [dict(r) for r in rows]


def fetch_one(conn, sql, params=None):
    cur = execute(conn, sql, params)
    row = cur.fetchone()
    return dict(row) if row else None


def commit(conn):
    conn.commit()


def insert_and_get_id(conn, table, columns, values):
    collist = ",".join(f'"{c}"' for c in columns)
    placeholders = ",".join(["?"] * len(values))
    if IS_POSTGRES:
        sql = f'INSERT INTO {table} ({collist}) VALUES ({placeholders}) RETURNING id'
        cur = execute(conn, sql, values)
        row = cur.fetchone()
        new_id = row["id"]
    else:
        sql = f'INSERT INTO {table} ({collist}) VALUES ({placeholders})'
        cur = execute(conn, sql, values)
        new_id = cur.lastrowid
    conn.commit()
    return new_id


def update_row(conn, table, columns, values, row_id):
    setlist = ",".join(f'"{c}" = ?' for c in columns)
    sql = f'UPDATE {table} SET {setlist} WHERE id = ?'
    execute(conn, sql, list(values) + [row_id])
    conn.commit()


def delete_row(conn, table, row_id):
    execute(conn, f'DELETE FROM {table} WHERE id = ?', [row_id])
    conn.commit()
