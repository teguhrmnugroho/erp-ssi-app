#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Membuat seluruh tabel (kalau belum ada) + mengisi data referensi (dropdown)
dan user default per role. Aman dijalankan berkali-kali (idempotent untuk
reference_values & users; CREATE TABLE pakai IF NOT EXISTS).

Pemakaian:
    python3 scripts/seed.py            # pakai DATABASE_URL kalau ada, else SQLite lokal
"""
import os
import sys

APP_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, APP_ROOT)

from app.db.conn import get_connection, execute, fetch_one, IS_POSTGRES  # noqa
from app.db.ddl import generate_all_ddl, REFERENCE_DOMAINS  # noqa
from app.auth_utils import hash_password  # noqa
from app.permissions import DEFAULT_USERS  # noqa


def create_tables(conn):
    dialect = "postgres" if IS_POSTGRES else "sqlite"
    stmts = generate_all_ddl(dialect)
    cur = conn.cursor()
    for s in stmts:
        cur.execute(s)
    conn.commit()
    print(f"[seed] {len(stmts)} statement DDL dijalankan ({dialect}).")


def seed_reference_values(conn):
    existing = fetch_one(conn, "SELECT COUNT(*) as c FROM reference_values")
    if existing and existing["c"] > 0:
        print(f"[seed] reference_values sudah berisi {existing['c']} baris, dilewati.")
        return
    n = 0
    for domain, values in REFERENCE_DOMAINS.items():
        for i, label in enumerate(values):
            execute(conn, "INSERT INTO reference_values (domain, label, urutan, status_aktif) VALUES (?, ?, ?, ?)",
                    [domain, label, i, 1])
            n += 1
    conn.commit()
    print(f"[seed] {n} nilai referensi dimasukkan ke {len(REFERENCE_DOMAINS)} domain.")


def seed_users(conn):
    for username, full_name, role, password in DEFAULT_USERS:
        existing = fetch_one(conn, "SELECT id FROM users WHERE username = ?", [username])
        if existing:
            continue
        pwd_hash = hash_password(password)
        execute(conn, "INSERT INTO users (username, password_hash, full_name, role, active) VALUES (?, ?, ?, ?, ?)",
                [username, pwd_hash, full_name, role, 1])
    conn.commit()
    print(f"[seed] {len(DEFAULT_USERS)} user default dipastikan ada (admin + 9 role).")


def main():
    conn = get_connection()
    create_tables(conn)
    seed_reference_values(conn)
    seed_users(conn)
    conn.close()
    print("[seed] Selesai.")


if __name__ == "__main__":
    main()
