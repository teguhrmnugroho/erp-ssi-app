CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  username TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  full_name TEXT NOT NULL,
  role TEXT NOT NULL,
  active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS reference_values (
  id SERIAL PRIMARY KEY,
  domain TEXT NOT NULL,
  label TEXT NOT NULL,
  urutan INTEGER DEFAULT 0,
  status_aktif BOOLEAN DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS tbl_gudang (
  id SERIAL PRIMARY KEY,
  "kode_gudang" TEXT,
  "nama_gudang" TEXT,
  "fungsi_utama" TEXT,
  "alamat_lokasi" TEXT,
  "status_aktif" BOOLEAN,
  "created_at" TIMESTAMP DEFAULT NOW(),
  "updated_at" TIMESTAMP DEFAULT NOW(),
  "created_by" TEXT,
  "updated_by" TEXT
);

CREATE UNIQUE INDEX IF NOT EXISTS ux_gudang_kode_gudang ON tbl_gudang ("kode_gudang");

CREATE TABLE IF NOT EXISTS tbl_produk (
  id SERIAL PRIMARY KEY,
  "no_produk" TEXT,
  "komoditas" TEXT,
  "bentuk_output" TEXT,
  "grade_kualitas" TEXT,
  "ukuran_stick_mm" NUMERIC(18,4),
  "spesifikasi_vo_persen" NUMERIC(18,4),
  "hs_code" TEXT,
  "harga_acuan_rp_kg" NUMERIC(18,4),
  "status" TEXT,
  "catatan" TEXT,
  "created_at" TIMESTAMP DEFAULT NOW(),
  "updated_at" TIMESTAMP DEFAULT NOW(),
  "created_by" TEXT,
  "updated_by" TEXT
);

CREATE UNIQUE INDEX IF NOT EXISTS ux_produk_no_produk ON tbl_produk ("no_produk");

CREATE TABLE IF NOT EXISTS tbl_mesin (
  id SERIAL PRIMARY KEY,
  "no_mesin" TEXT,
  "nama_mesin" TEXT,
  "jenis_mesin" TEXT,
  "gudang_lokasi" TEXT,
  "kapasitas_kg_jam" NUMERIC(18,4),
  "tarif_per_jam_rp" NUMERIC(18,4),
  "tahun_perolehan" INTEGER,
  "status" TEXT,
  "catatan" TEXT,
  "created_at" TIMESTAMP DEFAULT NOW(),
  "updated_at" TIMESTAMP DEFAULT NOW(),
  "created_by" TEXT,
  "updated_by" TEXT
);

CREATE UNIQUE INDEX IF NOT EXISTS ux_mesin_no_mesin ON tbl_mesin ("no_mesin");

CREATE TABLE IF NOT EXISTS tbl_lokasi_gudang (
  id SERIAL PRIMARY KEY,
  "no_lokasi" TEXT,
  "gudang" TEXT,
  "zona_lantai" TEXT,
  "kode_lokasi_bin" TEXT,
  "jenis_lokasi" TEXT,
  "kapasitas_kg" NUMERIC(18,4),
  "terisi_saat_ini_kg" NUMERIC(18,4),
  "sisa_kapasitas_kg" NUMERIC(18,4),
  "status" TEXT,
  "catatan" TEXT,
  "created_at" TIMESTAMP DEFAULT NOW(),
  "updated_at" TIMESTAMP DEFAULT NOW(),
  "created_by" TEXT,
  "updated_by" TEXT
);

CREATE UNIQUE INDEX IF NOT EXISTS ux_lokasi_gudang_no_lokasi ON tbl_lokasi_gudang ("no_lokasi");

CREATE TABLE IF NOT EXISTS tbl_buyer (
  id SERIAL PRIMARY KEY,
  "no_buyer" TEXT,
  "nama_buyer" TEXT,
  "tujuan_penjualan" TEXT,
  "negara_lokasi" TEXT,
  "kontak" TEXT,
  "total_po_all_time" INTEGER,
  "total_nilai_po_rp" NUMERIC(18,4),
  "nilai_po_tahun_berjalan_rp" NUMERIC(18,4),
  "rata_rata_nilai_per_po_rp" NUMERIC(18,4),
  "tanggal_po_terakhir" DATE,
  "proyeksi_nilai_12_bulan_rp" NUMERIC(18,4),
  "persen_dari_total_revenue" NUMERIC(18,4),
  "catatan" TEXT,
  "alamat" TEXT,
  "incoterm" TEXT,
  "term_pembayaran_default" TEXT,
  "status" TEXT,
  "created_at" TIMESTAMP DEFAULT NOW(),
  "updated_at" TIMESTAMP DEFAULT NOW(),
  "created_by" TEXT,
  "updated_by" TEXT
);

CREATE UNIQUE INDEX IF NOT EXISTS ux_buyer_no_buyer ON tbl_buyer ("no_buyer");

CREATE TABLE IF NOT EXISTS tbl_supplier (
  id SERIAL PRIMARY KEY,
  "no_supplier" TEXT,
  "nama_supplier" TEXT,
  "status_asl" TEXT,
  "kategori_rm" TEXT,
  "kontak" TEXT,
  "total_transaksi_all_time" INTEGER,
  "total_nilai_pembelian_rp" NUMERIC(18,4),
  "nilai_pembelian_tahun_berjalan_rp" NUMERIC(18,4),
  "rata_rata_nilai_per_transaksi_rp" NUMERIC(18,4),
  "tanggal_pembelian_terakhir" DATE,
  "proyeksi_kebutuhan_12_bulan_rp" NUMERIC(18,4),
  "catatan" TEXT,
  "created_at" TIMESTAMP DEFAULT NOW(),
  "updated_at" TIMESTAMP DEFAULT NOW(),
  "created_by" TEXT,
  "updated_by" TEXT
);

CREATE UNIQUE INDEX IF NOT EXISTS ux_supplier_no_supplier ON tbl_supplier ("no_supplier");

CREATE TABLE IF NOT EXISTS tbl_pekerja (
  id SERIAL PRIMARY KEY,
  "no_pekerja" TEXT,
  "nama" TEXT,
  "jenis_tenaga_kerja" TEXT,
  "jenis_kelamin" TEXT,
  "jenis_pekerjaan" TEXT,
  "status" TEXT,
  "created_at" TIMESTAMP DEFAULT NOW(),
  "updated_at" TIMESTAMP DEFAULT NOW(),
  "created_by" TEXT,
  "updated_by" TEXT
);

CREATE UNIQUE INDEX IF NOT EXISTS ux_pekerja_no_pekerja ON tbl_pekerja ("no_pekerja");

CREATE TABLE IF NOT EXISTS tbl_proses (
  id SERIAL PRIMARY KEY,
  "no_proses" TEXT,
  "nama_proses" TEXT,
  "kategori" TEXT,
  "urutan_default" INTEGER,
  "created_at" TIMESTAMP DEFAULT NOW(),
  "updated_at" TIMESTAMP DEFAULT NOW(),
  "created_by" TEXT,
  "updated_by" TEXT
);

CREATE UNIQUE INDEX IF NOT EXISTS ux_proses_no_proses ON tbl_proses ("no_proses");

CREATE TABLE IF NOT EXISTS tbl_referensi (
  id SERIAL PRIMARY KEY,
  "kode_domain" TEXT,
  "kode_nilai" TEXT,
  "label" TEXT,
  "urutan" INTEGER,
  "status_aktif" BOOLEAN,
  "created_at" TIMESTAMP DEFAULT NOW(),
  "updated_at" TIMESTAMP DEFAULT NOW(),
  "created_by" TEXT,
  "updated_by" TEXT
);

CREATE UNIQUE INDEX IF NOT EXISTS ux_referensi_kode_domain ON tbl_referensi ("kode_domain");

CREATE TABLE IF NOT EXISTS tbl_po_maklon (
  id SERIAL PRIMARY KEY,
  "no_po" TEXT,
  "tanggal_po" DATE,
  "no_quotation" TEXT,
  "tanggal_quotation" DATE,
  "tgl_expired_quotation" DATE,
  "nama_buyer_klien" TEXT,
  "jenis_po" TEXT,
  "tujuan_penjualan" TEXT,
  "deskripsi_produk" TEXT,
  "bentuk_output" TEXT,
  "qty" NUMERIC(18,4),
  "satuan" TEXT,
  "harga_satuan_rp" NUMERIC(18,4),
  "nilai_po_rp" NUMERIC(18,4),
  "pola_pembayaran" TEXT,
  "sumber_dana_funder" TEXT,
  "sertifikasi_diminta" TEXT,
  "target_tgl_kirim" DATE,
  "status_po" TEXT,
  "piutang_diakui_rp" NUMERIC(18,4),
  "catatan" TEXT,
  "grade_kualitas" TEXT,
  "ukuran_stick_mm" NUMERIC(18,4),
  "spesifikasi_vo_persen" NUMERIC(18,4),
  "no_produk_sku" TEXT,
  "created_at" TIMESTAMP DEFAULT NOW(),
  "updated_at" TIMESTAMP DEFAULT NOW(),
  "created_by" TEXT,
  "updated_by" TEXT
);

CREATE UNIQUE INDEX IF NOT EXISTS ux_po_maklon_no_po ON tbl_po_maklon ("no_po");

CREATE TABLE IF NOT EXISTS tbl_po_penjualan (
  id SERIAL PRIMARY KEY,
  "no_po" TEXT,
  "tanggal_po" DATE,
  "no_quotation" TEXT,
  "tanggal_quotation" DATE,
  "tgl_expired_quotation" DATE,
  "nama_buyer_klien" TEXT,
  "jenis_po" TEXT,
  "tujuan_penjualan" TEXT,
  "deskripsi_produk" TEXT,
  "bentuk_output" TEXT,
  "qty" NUMERIC(18,4),
  "satuan" TEXT,
  "harga_satuan_rp" NUMERIC(18,4),
  "nilai_po_rp" NUMERIC(18,4),
  "pola_pembayaran" TEXT,
  "sumber_dana_funder" TEXT,
  "sertifikasi_diminta" TEXT,
  "target_tgl_kirim" DATE,
  "status_po" TEXT,
  "piutang_diakui_rp" NUMERIC(18,4),
  "catatan" TEXT,
  "grade_kualitas" TEXT,
  "ukuran_stick_mm" NUMERIC(18,4),
  "spesifikasi_vo_persen" NUMERIC(18,4),
  "no_produk_sku" TEXT,
  "created_at" TIMESTAMP DEFAULT NOW(),
  "updated_at" TIMESTAMP DEFAULT NOW(),
  "created_by" TEXT,
  "updated_by" TEXT
);

CREATE UNIQUE INDEX IF NOT EXISTS ux_po_penjualan_no_po ON tbl_po_penjualan ("no_po");

CREATE TABLE IF NOT EXISTS tbl_po_index (
  id SERIAL PRIMARY KEY,
  "no_po_gabungan" TEXT,
  "sumber" TEXT,
  "created_at" TIMESTAMP DEFAULT NOW(),
  "updated_at" TIMESTAMP DEFAULT NOW(),
  "created_by" TEXT,
  "updated_by" TEXT
);

CREATE UNIQUE INDEX IF NOT EXISTS ux_po_index_no_po_gabungan ON tbl_po_index ("no_po_gabungan");

CREATE TABLE IF NOT EXISTS tbl_termin_pembayaran (
  id SERIAL PRIMARY KEY,
  "no_po" TEXT,
  "urutan_termin" INTEGER,
  "deskripsi_termin" TEXT,
  "persentase_persen" NUMERIC(18,4),
  "nilai_termin_rp" NUMERIC(18,4),
  "tanggal_jatuh_tempo" DATE,
  "tanggal_dibayar" DATE,
  "status" TEXT,
  "aging_hari" INTEGER,
  "created_at" TIMESTAMP DEFAULT NOW(),
  "updated_at" TIMESTAMP DEFAULT NOW(),
  "created_by" TEXT,
  "updated_by" TEXT
);

CREATE UNIQUE INDEX IF NOT EXISTS ux_termin_pembayaran_no_po ON tbl_termin_pembayaran ("no_po");

CREATE TABLE IF NOT EXISTS tbl_monitoring_penagihan (
  id SERIAL PRIMARY KEY,
  "no_monitoring" TEXT,
  "no_po" TEXT,
  "deskripsi_termin_ditagih" TEXT,
  "no_surat_penagihan" TEXT,
  "tanggal_surat_dikirim" DATE,
  "metode_penagihan" TEXT,
  "tanggal_balasan_diterima" DATE,
  "isi_balasan_hasil" TEXT,
  "status_penagihan" TEXT,
  "tanggal_janji_bayar" DATE,
  "catatan" TEXT,
  "created_at" TIMESTAMP DEFAULT NOW(),
  "updated_at" TIMESTAMP DEFAULT NOW(),
  "created_by" TEXT,
  "updated_by" TEXT
);

CREATE UNIQUE INDEX IF NOT EXISTS ux_monitoring_penagihan_no_monitoring ON tbl_monitoring_penagihan ("no_monitoring");

CREATE TABLE IF NOT EXISTS tbl_batch_produksi (
  id SERIAL PRIMARY KEY,
  "no_batch" TEXT,
  "no_po_terkait" TEXT,
  "tanggal_mulai" DATE,
  "gudang_produksi" TEXT,
  "nama_item_produk" TEXT,
  "kepemilikan_rm" TEXT,
  "nama_klien_jika_titipan" TEXT,
  "jml_rm_digunakan" NUMERIC(18,4),
  "satuan" TEXT,
  "bentuk_output" TEXT,
  "jml_output_yield" NUMERIC(18,4),
  "rendemen_persen" NUMERIC(18,4),
  "status_qc_inhouse" TEXT,
  "tgl_qc_inhouse" DATE,
  "hasil_lab_inhouse" TEXT,
  "hasil_lab_pemerintah" TEXT,
  "hasil_lab_buyer" TEXT,
  "tgl_konfirmasi_buyer" DATE,
  "status_konfirmasi_buyer" TEXT,
  "fumigasi" BOOLEAN,
  "status_batch" TEXT,
  "catatan" TEXT,
  "created_at" TIMESTAMP DEFAULT NOW(),
  "updated_at" TIMESTAMP DEFAULT NOW(),
  "created_by" TEXT,
  "updated_by" TEXT
);

CREATE UNIQUE INDEX IF NOT EXISTS ux_batch_produksi_no_batch ON tbl_batch_produksi ("no_batch");

CREATE TABLE IF NOT EXISTS tbl_neraca_bahan (
  id SERIAL PRIMARY KEY,
  "no_batch" TEXT,
  "urutan_tahap" INTEGER,
  "nama_proses" TEXT,
  "satuan" TEXT,
  "qty_input" NUMERIC(18,4),
  "qty_output" NUMERIC(18,4),
  "qty_byproduct" NUMERIC(18,4),
  "qty_loss_susut" NUMERIC(18,4),
  "rendemen_tahap_persen" NUMERIC(18,4),
  "gudang" TEXT,
  "catatan" TEXT,
  "created_at" TIMESTAMP DEFAULT NOW(),
  "updated_at" TIMESTAMP DEFAULT NOW(),
  "created_by" TEXT,
  "updated_by" TEXT
);

CREATE UNIQUE INDEX IF NOT EXISTS ux_neraca_bahan_no_batch ON tbl_neraca_bahan ("no_batch");

CREATE TABLE IF NOT EXISTS tbl_timeline_produksi (
  id SERIAL PRIMARY KEY,
  "no_batch" TEXT,
  "no_po_terkait" TEXT,
  "tahap" TEXT,
  "rencana_mulai" DATE,
  "rencana_selesai" DATE,
  "durasi_rencana_hari" INTEGER,
  "aktual_mulai" DATE,
  "aktual_selesai" DATE,
  "durasi_aktual_hari" INTEGER,
  "selisih_hari" INTEGER,
  "status" TEXT,
  "pic" TEXT,
  "catatan" TEXT,
  "created_at" TIMESTAMP DEFAULT NOW(),
  "updated_at" TIMESTAMP DEFAULT NOW(),
  "created_by" TEXT,
  "updated_by" TEXT
);

CREATE UNIQUE INDEX IF NOT EXISTS ux_timeline_produksi_no_batch ON tbl_timeline_produksi ("no_batch");

CREATE TABLE IF NOT EXISTS tbl_pemakaian_mesin (
  id SERIAL PRIMARY KEY,
  "no_log" TEXT,
  "no_batch" TEXT,
  "tahap_proses" TEXT,
  "no_mesin" TEXT,
  "tanggal" DATE,
  "jam_mulai" TIME,
  "jam_selesai" TIME,
  "jumlah_jam_pakai" NUMERIC(18,4),
  "qty_diproses_kg" NUMERIC(18,4),
  "kapasitas_mesin_kg_jam" NUMERIC(18,4),
  "utilisasi_persen" NUMERIC(18,4),
  "konsumsi_energi_kwh" NUMERIC(18,4),
  "biaya_mesin_rp" NUMERIC(18,4),
  "pic" TEXT,
  "created_at" TIMESTAMP DEFAULT NOW(),
  "updated_at" TIMESTAMP DEFAULT NOW(),
  "created_by" TEXT,
  "updated_by" TEXT
);

CREATE UNIQUE INDEX IF NOT EXISTS ux_pemakaian_mesin_no_log ON tbl_pemakaian_mesin ("no_log");

CREATE TABLE IF NOT EXISTS tbl_stok_rm (
  id SERIAL PRIMARY KEY,
  "no_stok_lot" TEXT,
  "gudang" TEXT,
  "nama_item_rm" TEXT,
  "kepemilikan" TEXT,
  "nama_klien_jika_titipan" TEXT,
  "nama_supplier_jika_milik_ssi" TEXT,
  "tanggal_masuk" DATE,
  "jumlah_masuk" NUMERIC(18,4),
  "jumlah_terpakai" NUMERIC(18,4),
  "satuan" TEXT,
  "sisa_stok" NUMERIC(18,4),
  "harga_satuan_rp" NUMERIC(18,4),
  "nilai_sisa_rp" NUMERIC(18,4),
  "nilai_terpakai_rp" NUMERIC(18,4),
  "status_stok" TEXT,
  "catatan" TEXT,
  "created_at" TIMESTAMP DEFAULT NOW(),
  "updated_at" TIMESTAMP DEFAULT NOW(),
  "created_by" TEXT,
  "updated_by" TEXT
);

CREATE UNIQUE INDEX IF NOT EXISTS ux_stok_rm_no_stok_lot ON tbl_stok_rm ("no_stok_lot");

CREATE TABLE IF NOT EXISTS tbl_mutasi_gudang (
  id SERIAL PRIMARY KEY,
  "no_mutasi" TEXT,
  "tanggal" DATE,
  "no_stok_lot_terkait" TEXT,
  "nama_item" TEXT,
  "dari_gudang" TEXT,
  "ke_gudang" TEXT,
  "jumlah" NUMERIC(18,4),
  "satuan" TEXT,
  "pic" TEXT,
  "status" TEXT,
  "catatan" TEXT,
  "created_at" TIMESTAMP DEFAULT NOW(),
  "updated_at" TIMESTAMP DEFAULT NOW(),
  "created_by" TEXT,
  "updated_by" TEXT
);

CREATE UNIQUE INDEX IF NOT EXISTS ux_mutasi_gudang_no_mutasi ON tbl_mutasi_gudang ("no_mutasi");

CREATE TABLE IF NOT EXISTS tbl_stock_opname (
  id SERIAL PRIMARY KEY,
  "no_opname" TEXT,
  "tanggal_opname" DATE,
  "gudang" TEXT,
  "no_stok_lot" TEXT,
  "nama_item" TEXT,
  "stok_sistem_sisa" NUMERIC(18,4),
  "stok_fisik_hitung_ulang" NUMERIC(18,4),
  "selisih" NUMERIC(18,4),
  "keterangan_selisih" TEXT,
  "pic_penghitung" TEXT,
  "status" TEXT,
  "created_at" TIMESTAMP DEFAULT NOW(),
  "updated_at" TIMESTAMP DEFAULT NOW(),
  "created_by" TEXT,
  "updated_by" TEXT
);

CREATE UNIQUE INDEX IF NOT EXISTS ux_stock_opname_no_opname ON tbl_stock_opname ("no_opname");

CREATE TABLE IF NOT EXISTS tbl_funder (
  id SERIAL PRIMARY KEY,
  "no_funder" TEXT,
  "nama_funder" TEXT,
  "jenis_funder" TEXT,
  "currency" TEXT,
  "kontak" TEXT,
  "status" TEXT,
  "created_at" TIMESTAMP DEFAULT NOW(),
  "updated_at" TIMESTAMP DEFAULT NOW(),
  "created_by" TEXT,
  "updated_by" TEXT
);

CREATE UNIQUE INDEX IF NOT EXISTS ux_funder_no_funder ON tbl_funder ("no_funder");

CREATE TABLE IF NOT EXISTS tbl_funding_facility (
  id SERIAL PRIMARY KEY,
  "no_facility" TEXT,
  "no_funder" TEXT,
  "nama_facility" TEXT,
  "jenis_facility" TEXT,
  "currency" TEXT,
  "facility_limit_rp" NUMERIC(18,4),
  "tanggal_mulai" DATE,
  "tanggal_jatuh_tempo" DATE,
  "tenor_bulan" INTEGER,
  "status" TEXT,
  "sisa_limit_rp" NUMERIC(18,4),
  "margin_persen" NUMERIC(18,4),
  "no_referensi_perjanjian" TEXT,
  "created_at" TIMESTAMP DEFAULT NOW(),
  "updated_at" TIMESTAMP DEFAULT NOW(),
  "created_by" TEXT,
  "updated_by" TEXT
);

CREATE UNIQUE INDEX IF NOT EXISTS ux_funding_facility_no_facility ON tbl_funding_facility ("no_facility");

CREATE TABLE IF NOT EXISTS tbl_funding_terms (
  id SERIAL PRIMARY KEY,
  "no_terms" TEXT,
  "no_facility" TEXT,
  "metode_cost_of_fund" TEXT,
  "interest_rate_persen" NUMERIC(18,4),
  "profit_share_basis" TEXT,
  "revenue_share_persen" NUMERIC(18,4),
  "fixed_fee_rp" NUMERIC(18,4),
  "commitment_fee_persen" NUMERIC(18,4),
  "arrangement_fee_persen" NUMERIC(18,4),
  "tanggal_efektif" DATE,
  "created_at" TIMESTAMP DEFAULT NOW(),
  "updated_at" TIMESTAMP DEFAULT NOW(),
  "created_by" TEXT,
  "updated_by" TEXT
);

CREATE UNIQUE INDEX IF NOT EXISTS ux_funding_terms_no_terms ON tbl_funding_terms ("no_terms");

CREATE TABLE IF NOT EXISTS tbl_drawdown (
  id SERIAL PRIMARY KEY,
  "no_drawdown" TEXT,
  "no_facility" TEXT,
  "tanggal_drawdown" DATE,
  "nilai_pokok_rp" NUMERIC(18,4),
  "tenor_hari" INTEGER,
  "tanggal_jatuh_tempo" DATE,
  "rate_terms_snapshot_persen" NUMERIC(18,4),
  "status" TEXT,
  "sisa_alokasi_rp" NUMERIC(18,4),
  "created_at" TIMESTAMP DEFAULT NOW(),
  "updated_at" TIMESTAMP DEFAULT NOW(),
  "created_by" TEXT,
  "updated_by" TEXT
);

CREATE UNIQUE INDEX IF NOT EXISTS ux_drawdown_no_drawdown ON tbl_drawdown ("no_drawdown");

CREATE TABLE IF NOT EXISTS tbl_fund_allocation (
  id SERIAL PRIMARY KEY,
  "no_alokasi" TEXT,
  "no_drawdown" TEXT,
  "no_po" TEXT,
  "no_batch_opsional" TEXT,
  "nilai_dialokasikan_rp" NUMERIC(18,4),
  "persen_alokasi_dari_drawdown" NUMERIC(18,4),
  "tanggal_alokasi" DATE,
  "status" TEXT,
  "created_at" TIMESTAMP DEFAULT NOW(),
  "updated_at" TIMESTAMP DEFAULT NOW(),
  "created_by" TEXT,
  "updated_by" TEXT
);

CREATE UNIQUE INDEX IF NOT EXISTS ux_fund_allocation_no_alokasi ON tbl_fund_allocation ("no_alokasi");

CREATE TABLE IF NOT EXISTS tbl_funding_cost_ledger (
  id SERIAL PRIMARY KEY,
  "no_ledger" TEXT,
  "no_drawdown" TEXT,
  "jenis_biaya" TEXT,
  "basis_pokok_rp" NUMERIC(18,4),
  "jumlah_hari" INTEGER,
  "rate_persen" NUMERIC(18,4),
  "jumlah_biaya_rp" NUMERIC(18,4),
  "tanggal" DATE,
  "created_at" TIMESTAMP DEFAULT NOW(),
  "updated_at" TIMESTAMP DEFAULT NOW(),
  "created_by" TEXT,
  "updated_by" TEXT
);

CREATE UNIQUE INDEX IF NOT EXISTS ux_funding_cost_ledger_no_ledger ON tbl_funding_cost_ledger ("no_ledger");

CREATE TABLE IF NOT EXISTS tbl_profit_distribution (
  id SERIAL PRIMARY KEY,
  "no_distribusi" TEXT,
  "periode" TEXT,
  "no_facility" TEXT,
  "basis_profit_rp" NUMERIC(18,4),
  "persen_bagian_funder" NUMERIC(18,4),
  "nilai_bagian_funder_rp" NUMERIC(18,4),
  "nilai_bagian_ssi_rp" NUMERIC(18,4),
  "tanggal_distribusi" DATE,
  "status" TEXT,
  "created_at" TIMESTAMP DEFAULT NOW(),
  "updated_at" TIMESTAMP DEFAULT NOW(),
  "created_by" TEXT,
  "updated_by" TEXT
);

CREATE UNIQUE INDEX IF NOT EXISTS ux_profit_distribution_no_distribusi ON tbl_profit_distribution ("no_distribusi");

CREATE TABLE IF NOT EXISTS tbl_pengeluaran (
  id SERIAL PRIMARY KEY,
  "no_pengeluaran" TEXT,
  "tanggal" DATE,
  "kategori" TEXT,
  "deskripsi" TEXT,
  "no_po_terkait" TEXT,
  "no_batch_terkait" TEXT,
  "gudang_terkait" TEXT,
  "jumlah_rp" NUMERIC(18,4),
  "metode_pembayaran" TEXT,
  "status_pembayaran" TEXT,
  "pic_disetujui_oleh" TEXT,
  "catatan" TEXT,
  "bulan_bantu" TEXT,
  "created_at" TIMESTAMP DEFAULT NOW(),
  "updated_at" TIMESTAMP DEFAULT NOW(),
  "created_by" TEXT,
  "updated_by" TEXT
);

CREATE UNIQUE INDEX IF NOT EXISTS ux_pengeluaran_no_pengeluaran ON tbl_pengeluaran ("no_pengeluaran");

CREATE TABLE IF NOT EXISTS tbl_kas_kecil (
  id SERIAL PRIMARY KEY,
  "no_transaksi_kas" TEXT,
  "tanggal" DATE,
  "keterangan" TEXT,
  "kategori" TEXT,
  "no_bukti" TEXT,
  "kas_masuk_rp" NUMERIC(18,4),
  "kas_keluar_rp" NUMERIC(18,4),
  "saldo_rp" NUMERIC(18,4),
  "pic" TEXT,
  "no_pengeluaran_terkait" TEXT,
  "catatan" TEXT,
  "created_at" TIMESTAMP DEFAULT NOW(),
  "updated_at" TIMESTAMP DEFAULT NOW(),
  "created_by" TEXT,
  "updated_by" TEXT
);

CREATE UNIQUE INDEX IF NOT EXISTS ux_kas_kecil_no_transaksi_kas ON tbl_kas_kecil ("no_transaksi_kas");

CREATE TABLE IF NOT EXISTS tbl_surat (
  id SERIAL PRIMARY KEY,
  "no_surat" TEXT,
  "jenis_surat" TEXT,
  "nomor_surat" TEXT,
  "tanggal" DATE,
  "perihal" TEXT,
  "no_po_terkait" TEXT,
  "nama_klien_terkait" TEXT,
  "file_referensi" TEXT,
  "status" TEXT,
  "pic_disposisi" TEXT,
  "tanggal_disposisi" DATE,
  "status_tindak_lanjut" TEXT,
  "created_at" TIMESTAMP DEFAULT NOW(),
  "updated_at" TIMESTAMP DEFAULT NOW(),
  "created_by" TEXT,
  "updated_by" TEXT
);

CREATE UNIQUE INDEX IF NOT EXISTS ux_surat_no_surat ON tbl_surat ("no_surat");

CREATE TABLE IF NOT EXISTS tbl_rapat_tim (
  id SERIAL PRIMARY KEY,
  "no_rapat_tim" TEXT,
  "no_po_terkait" TEXT,
  "tanggal_rapat" DATE,
  "departemen_hadir" TEXT,
  "sumber_dana_disampaikan" TEXT,
  "ringkasan_arahan_produksi" TEXT,
  "pic_tindak_lanjut" TEXT,
  "status" TEXT,
  "catatan" TEXT,
  "created_at" TIMESTAMP DEFAULT NOW(),
  "updated_at" TIMESTAMP DEFAULT NOW(),
  "created_by" TEXT,
  "updated_by" TEXT
);

CREATE UNIQUE INDEX IF NOT EXISTS ux_rapat_tim_no_rapat_tim ON tbl_rapat_tim ("no_rapat_tim");

CREATE TABLE IF NOT EXISTS tbl_sertifikasi (
  id SERIAL PRIMARY KEY,
  "no_sertifikasi" TEXT,
  "jenis_sertifikasi" TEXT,
  "lembaga_penerbit" TEXT,
  "nomor_sertifikat" TEXT,
  "tanggal_terbit" DATE,
  "tanggal_kedaluwarsa" DATE,
  "sisa_hari" INTEGER,
  "status" TEXT,
  "catatan" TEXT,
  "created_at" TIMESTAMP DEFAULT NOW(),
  "updated_at" TIMESTAMP DEFAULT NOW(),
  "created_by" TEXT,
  "updated_by" TEXT
);

CREATE UNIQUE INDEX IF NOT EXISTS ux_sertifikasi_no_sertifikasi ON tbl_sertifikasi ("no_sertifikasi");

CREATE TABLE IF NOT EXISTS tbl_kehadiran (
  id SERIAL PRIMARY KEY,
  "no_kehadiran" TEXT,
  "no_pekerja" TEXT,
  "nama" TEXT,
  "tanggal" DATE,
  "jam_kerja" NUMERIC(18,4),
  "no_batch" TEXT,
  "leader_pelapor" TEXT,
  "bulan_bantu" TEXT,
  "akumulasi_hari_bulan_ini" INTEGER,
  "status_kepatuhan_21_hari" TEXT,
  "created_at" TIMESTAMP DEFAULT NOW(),
  "updated_at" TIMESTAMP DEFAULT NOW(),
  "created_by" TEXT,
  "updated_by" TEXT
);

CREATE UNIQUE INDEX IF NOT EXISTS ux_kehadiran_no_kehadiran ON tbl_kehadiran ("no_kehadiran");
